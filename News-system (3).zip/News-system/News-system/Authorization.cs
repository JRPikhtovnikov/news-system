﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace News_system {
    public class Authorization {

        private string? _username;
        private string? _password;

        public bool ValidateLogin(string username, string password) {
            _username = username;
            _password = password;
            return _username == "admin" && _password == "password";
        }
    }
}
