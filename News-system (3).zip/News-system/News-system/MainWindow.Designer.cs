﻿
namespace News_system {
    partial class MainWindow {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            lb_news = new ListBox();
            labelTitle = new Label();
            tb_content = new TextBox();
            btn_voteup = new Button();
            btn_votedown = new Button();
            btn_add_news = new Button();
            label2 = new Label();
            SuspendLayout();
            // 
            // lb_news
            // 
            lb_news.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            lb_news.FormattingEnabled = true;
            lb_news.ItemHeight = 15;
            lb_news.Location = new Point(12, 12);
            lb_news.Name = "lb_news";
            lb_news.Size = new Size(200, 334);
            lb_news.TabIndex = 0;
            lb_news.SelectedIndexChanged += this.lb_news_SelectedIndexChanged;
            // 
            // labelTitle
            // 
            labelTitle.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            labelTitle.AutoSize = true;
            labelTitle.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            labelTitle.Location = new Point(230, 12);
            labelTitle.Name = "labelTitle";
            labelTitle.Size = new Size(93, 21);
            labelTitle.TabIndex = 1;
            labelTitle.Text = "Заголовок";
            // 
            // tb_content
            // 
            tb_content.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tb_content.Location = new Point(230, 46);
            tb_content.Multiline = true;
            tb_content.Name = "tb_content";
            tb_content.ReadOnly = true;
            tb_content.ScrollBars = ScrollBars.Vertical;
            tb_content.Size = new Size(350, 300);
            tb_content.TabIndex = 2;
            // 
            // btn_voteup
            // 
            btn_voteup.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btn_voteup.Location = new Point(414, 360);
            btn_voteup.Name = "btn_voteup";
            btn_voteup.Size = new Size(75, 30);
            btn_voteup.TabIndex = 3;
            btn_voteup.Text = "👍";
            btn_voteup.UseVisualStyleBackColor = true;
            btn_voteup.Click += btn_voteup_Click;
            // 
            // btn_votedown
            // 
            btn_votedown.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btn_votedown.Location = new Point(505, 360);
            btn_votedown.Name = "btn_votedown";
            btn_votedown.Size = new Size(75, 30);
            btn_votedown.TabIndex = 4;
            btn_votedown.Text = "👎";
            btn_votedown.UseVisualStyleBackColor = true;
            btn_votedown.Click += btn_votedown_Click;
            // 
            // btn_add_news
            // 
            btn_add_news.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            btn_add_news.Location = new Point(12, 360);
            btn_add_news.Name = "btn_add_news";
            btn_add_news.Size = new Size(200, 30);
            btn_add_news.TabIndex = 5;
            btn_add_news.Text = "Добавить новость";
            btn_add_news.Click += btn_add_news_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label2.Location = new Point(230, 363);
            label2.Name = "label2";
            label2.Size = new Size(144, 21);
            label2.TabIndex = 6;
            label2.Text = "Оценить новость";
            // 
            // MainWindow
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(600, 400);
            Controls.Add(label2);
            Controls.Add(btn_add_news);
            Controls.Add(btn_votedown);
            Controls.Add(btn_voteup);
            Controls.Add(tb_content);
            Controls.Add(labelTitle);
            Controls.Add(lb_news);
            Name = "MainWindow";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Главное окно";
            ResumeLayout(false);
            PerformLayout();
        }


        #endregion

        private System.Windows.Forms.ListBox lb_news;
        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.TextBox tb_content;
        private System.Windows.Forms.Button btn_voteup;
        private System.Windows.Forms.Button btn_votedown;
        private Label label1;
        private Label label2;
        private Button btn_add_news;
    }
}
