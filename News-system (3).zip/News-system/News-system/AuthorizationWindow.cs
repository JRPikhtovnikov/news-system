﻿namespace News_system {
    public partial class AuthorizationWindow : Form {

        Authorization _model;

        public AuthorizationWindow(Authorization model) {
            _model = model;
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e) {

            if (_model.ValidateLogin(tb_username.Text, tb_password.Text)) {
                MessageBox.Show("Вход выполнен успешно!");
            }
            else {
                MessageBox.Show("Неверный логин или пароль!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_register_Click(object sender, EventArgs e) {
            // Открыть окно регистрации
            var registerForm = new AuthorizationWindow(_model);
            registerForm.ShowDialog();
        }

    }
}
