﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace News_system {
    public partial class RegistrationWindow : Form {
        public RegistrationWindow() {
            InitializeComponent();
        }

        private void btn_register_Click(object sender, EventArgs e) {

        }

        private void btn_cancel_Click(object sender, EventArgs e) {

        }
    }
}
