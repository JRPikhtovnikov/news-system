﻿using System;
using MySql.Data.MySqlClient;

namespace News_System {
    public static class RegistrationMain {
        // Параметры подключения к базе данных
        private static string connectionString = "Server=localhost;Database=NewsSystem;Uid=root;Pwd=your_password;";

        /// <summary>
        /// Регистрирует нового пользователя в базе данных.
        /// </summary>
        /// <param name="username">Имя пользователя.</param>
        /// <param name="passwordHash">Хэш пароля.</param>
        /// <param name="email">Email пользователя.</param>
        /// <returns>True, если регистрация успешна, иначе False.</returns>
        public static bool RegisterUser(string username, string passwordHash, string email) {
            try {
                using (var connection = new MySqlConnection(connectionString)) {
                    connection.Open();

                    // Проверка существования пользователя с таким именем или email
                    string checkUserQuery = "SELECT COUNT(*) FROM Users WHERE Username = @Username OR Email = @Email;";
                    using (var checkCommand = new MySqlCommand(checkUserQuery, connection)) {
                        checkCommand.Parameters.AddWithValue("@Username", username);
                        checkCommand.Parameters.AddWithValue("@Email", email);

                        long count = (long)checkCommand.ExecuteScalar();
                        if (count > 0) {
                            return false; // Пользователь уже существует
                        }
                    }

                    // Добавление нового пользователя
                    string insertQuery = "INSERT INTO Users (Username, PasswordHash, Email) VALUES (@Username, @PasswordHash, @Email);";
                    using (var insertCommand = new MySqlCommand(insertQuery, connection)) {
                        insertCommand.Parameters.AddWithValue("@Username", username);
                        insertCommand.Parameters.AddWithValue("@PasswordHash", passwordHash);
                        insertCommand.Parameters.AddWithValue("@Email", email);

                        int rowsInserted = insertCommand.ExecuteNonQuery();
                        return rowsInserted > 0; // Успешно добавлено
                    }
                }
            }
            catch (Exception ex) {
                // Логирование ошибки (можно дополнительно настроить логирование в файл или консоль)
                Console.WriteLine($"Ошибка регистрации: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Генерация хэша пароля (реализуйте надежный механизм хэширования).
        /// </summary>
        /// <param name="password">Пароль пользователя.</param>
        /// <returns>Хэш пароля.</returns>
        public static string GeneratePasswordHash(string password) {
            // Простая реализация хэширования (для демонстрации)
            using (var sha256 = System.Security.Cryptography.SHA256.Create()) {
                byte[] bytes = System.Text.Encoding.UTF8.GetBytes(password);
                byte[] hash = sha256.ComputeHash(bytes);
                return Convert.ToBase64String(hash);
            }
        }
    }
}
